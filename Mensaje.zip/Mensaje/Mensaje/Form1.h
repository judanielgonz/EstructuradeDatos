#pragma once

namespace Mensaje {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Button^  boton;
	private: System::Windows::Forms::TextBox^  texto;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->boton = (gcnew System::Windows::Forms::Button());
			this->texto = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->ForeColor = System::Drawing::Color::Red;
			this->label1->Location = System::Drawing::Point(86, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(102, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"HOLA MUNDO";
			// 
			// boton
			// 
			this->boton->Location = System::Drawing::Point(29, 138);
			this->boton->Name = L"boton";
			this->boton->Size = System::Drawing::Size(227, 30);
			this->boton->TabIndex = 1;
			this->boton->Text = L"Presione para mostar el Mensaje";
			this->boton->UseVisualStyleBackColor = true;
			this->boton->Click += gcnew System::EventHandler(this, &Form1::boton_Click);
			// 
			// texto
			// 
			this->texto->Location = System::Drawing::Point(59, 57);
			this->texto->Name = L"texto";
			this->texto->Size = System::Drawing::Size(165, 22);
			this->texto->TabIndex = 2;
			this->texto->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->texto);
			this->Controls->Add(this->boton);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void boton_Click(System::Object^  sender, System::EventArgs^  e) {
				 texto->Text="Feliz carnaval";
			 }
	};
}

