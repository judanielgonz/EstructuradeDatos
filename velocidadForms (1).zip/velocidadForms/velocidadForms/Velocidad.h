#pragma once
class Velocidad
{
private:  //atributos
	int distancia;
	int tiempo;

public:					//metodos
	Velocidad(void);	//constructor

	int Get_distancia();
	int Get_tiempo();

	void Set_distancia(int d);
	void Set_tiempo(int t);

	int Calcular();
};

