#include "StdAfx.h"
#include "Velocidad.h"


Velocidad::Velocidad(void)
{
}
//para accesar o revisar el contenido de los atributos
 int Velocidad::Get_distancia()
 {
	return distancia;
 }
 int Velocidad::Get_tiempo()
 {
	 return tiempo;
 }

 void Velocidad::Set_distancia(int d)
 {
	 distancia=d;
 }
 void Velocidad::Set_tiempo(int t)
 {
	 tiempo=t;
 }

 int Velocidad::Calcular()
 {
	 return (distancia/tiempo);
 }